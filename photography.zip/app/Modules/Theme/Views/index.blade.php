<?php

echo trans('Theme::example.welcome');