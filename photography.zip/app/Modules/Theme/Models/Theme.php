<?php

namespace App\Modules\Theme\Models;

use Illuminate\Database\Eloquent\Model;

class Theme extends Model {

    //

}
