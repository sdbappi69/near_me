<?php 

return [
    'welcome' => 'Welcome, this is Theme module.'
];
