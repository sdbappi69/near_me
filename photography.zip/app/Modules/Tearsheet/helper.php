<?php

/**
 *	Tearsheet Helper  
 */