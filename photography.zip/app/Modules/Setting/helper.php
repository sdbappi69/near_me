<?php

/**
 *	Setting Helper  
 */