<?php 

return [
    'welcome' => 'Welcome, this is Setting module.'
];
