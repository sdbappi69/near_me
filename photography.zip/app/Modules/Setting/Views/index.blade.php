<?php

echo trans('Setting::example.welcome');