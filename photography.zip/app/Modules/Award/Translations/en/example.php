<?php 

return [
    'welcome' => 'Welcome, this is Award module.'
];
