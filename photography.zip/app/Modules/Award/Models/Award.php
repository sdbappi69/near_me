<?php

namespace App\Modules\Award\Models;

use Illuminate\Database\Eloquent\Model;

class Award extends Model {

    //

}
