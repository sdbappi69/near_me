<?php

namespace App\Modules\Slider\Models;

use Illuminate\Database\Eloquent\Model;

class Slider extends Model {

    //

}
