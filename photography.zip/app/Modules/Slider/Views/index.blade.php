<?php

echo trans('Slider::example.welcome');