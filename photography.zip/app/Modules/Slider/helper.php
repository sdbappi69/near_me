<?php

/**
 *	Slider Helper  
 */