<?php 

return [
    'welcome' => 'Welcome, this is Slider module.'
];
