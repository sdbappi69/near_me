<?php

namespace App\Modules\MenuHead\Models;

use Illuminate\Database\Eloquent\Model;

class MenuHead extends Model {

    //

}
