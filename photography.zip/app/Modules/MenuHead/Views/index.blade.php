<?php

echo trans('MenuHead::example.welcome');