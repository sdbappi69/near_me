<?php 

return [
    'welcome' => 'Welcome, this is Testimonial module.'
];
