<?php 

return [
    'welcome' => 'Welcome, this is Category module.'
];
