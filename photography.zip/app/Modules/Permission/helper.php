<?php

/**
 *	Permission Helper  
 */