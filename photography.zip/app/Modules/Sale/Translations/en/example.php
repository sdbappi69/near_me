<?php 

return [
    'welcome' => 'Welcome, this is Sale module.'
];
