<?php 

return [
    'welcome' => 'Welcome, this is SocialNetwork module.'
];
