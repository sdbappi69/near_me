<?php

namespace App\Modules\SocialNetwork\Models;

use Illuminate\Database\Eloquent\Model;

class SocialNetwork extends Model {

    //

}
