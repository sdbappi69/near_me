<?php

echo trans('SocialNetwork::example.welcome');