<?php 

return [
    'welcome' => 'Welcome, this is PrintSale module.'
];
