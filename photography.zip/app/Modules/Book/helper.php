<?php

/**
 *	Book Helper  
 */