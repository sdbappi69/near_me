<?php 

return [
    'welcome' => 'Welcome, this is Book module.'
];
