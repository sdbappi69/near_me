<?php

namespace App\Modules\Book\Models;

use Illuminate\Database\Eloquent\Model;

class Book extends Model {

    //

}
