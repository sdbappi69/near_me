<?php

/**
 *	Photo Helper  
 */