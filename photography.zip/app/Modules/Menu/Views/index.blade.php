<?php

echo trans('Menu::example.welcome');