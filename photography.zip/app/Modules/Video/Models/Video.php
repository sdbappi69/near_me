<?php

namespace App\Modules\Video\Models;

use Illuminate\Database\Eloquent\Model;

class Video extends Model {

    //

}
