<?php 

return [
    'welcome' => 'Welcome, this is Video module.'
];
