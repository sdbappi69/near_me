<?php 

return [
    'welcome' => 'Welcome, this is Size module.'
];
