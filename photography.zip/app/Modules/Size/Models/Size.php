<?php

namespace App\Modules\Size\Models;

use Illuminate\Database\Eloquent\Model;

class Size extends Model {

    //

}
