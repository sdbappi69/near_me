<?php

namespace App\Modules\Biography\Models;

use Illuminate\Database\Eloquent\Model;

class Biography extends Model {

    //

}
