<?php

/**
 *	Biography Helper  
 */